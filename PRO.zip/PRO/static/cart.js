/*CART CODE */
var cart_data = JSON.parse("{{cart_data|escapejs}}");
var cart_count = JSON.parse("{{cart_count|escapejs}}");
document.getElementById('cart_no').innerText=cart_count;
/*CART CODE */
var all=[];
all.push(cart_data);
cart=document.getElementById('cart_no');
function addtocart(price,qty,name,pic){
  cart_no=parseInt(cart.innerText);
  var add_price=parseInt(price.options[price.selectedIndex].text);
  var rate = price.options[price.selectedIndex].text
  if(add_price==0){
    alert('This option is Not Avaiable');
  }
  else{
    if(user=='AnonymousUser'){
      var total =add_price*parseInt(qty.value);
      all.push([pic.src,name.innerHTML,qty.value,rate,total]);
      console.log(all)
      $.ajax({
        type:"GET",
        url: "/addtocart",
        data:{
          user:user,
          cart_count: cart_no,
          cart_data:all.toString(),
        },
        success: function( new_cart_no ) 
          {
            document.getElementById('cart_no').innerText=new_cart_no
          }
      })
    }
  }
}