from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('index/',views.index,name='index'),
    path('index/allfruit/',views.allfruit,name='allfruit'),
    path('index/allveg/',views.allveg,name='allveg'),
    path('index/alloffers/',views.alloffers,name='alloffers'),
    path('index/cart_data/',views.cart_data,name='cart_data'),
    path('index/about/',views.about,name='about'),
    path('register/',views.register,name="register"),
    path('login/',views.login,name='login'),
    path('loginAdmin/',views.loginAdmin,name='loginAdmin'),
    path('login/forget',views.forget,name='forget'),
    path('logout/',views.logout,name='logout'),

    path('quickview/<int:mid>',views.quickview,name='quickview'),
    path('login/quickview/<int:mid>',views.quickview,name='quickview'),
    path('index/quickview/<int:mid>',views.quickview,name='quickview'),
    path('index/allfruit/quickview/<int:mid>',views.quickview,name='quickview'),
    path('index/allveg/quickview/<int:mid>',views.quickview,name='quickview'),
    path('index/alloffers/quickview/<int:mid>',views.quickview,name='quickview'),


    path('profile1/', views.profile1, name='profile1'),
    path('profile1/customer_orders/<str:ids>', views.customer_orders, name='customer_orders'),
    path('addtocart/', views.addtocart, name='addtocart'),
    path('updatecart/', views.updatecart, name='updatecart'),
    path('index/cart_data/checkout/', views.checkout, name='checkout'),
    path('index/cart_data/checkout/placeorder', views.placeorder, name='placeorder'),
    path('profile/', views.profile, name='profile'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('dashboard/dash/<str:ids>', views.dash, name='dash'),
    path("handlerequest/", views.handlerequest, name="HandleRequest"),
#search url
    path('index/search',views.search,name='search'),
    path('index/quickview/search',views.search,name='search'),
    path('index/allfruit/quickview/search',views.search,name='search'),
    path('index/allveg/quickview/search',views.search,name='search'),
    path('index/alloffers/quickview/search',views.search,name='search'),
    path('index/search',views.search,name='search'),
    path('login/search',views.search,name='search'),
    path('register/search',views.search,name='search'),
    path('index/allfruit/search',views.search,name='search'),
    path('index/allveg/search',views.search,name='search'),
    path('index/alloffers/search',views.search,name='search'),
    path('index/cart_data/checkout/search', views.search, name='search'),
    path('index/cart_data/search', views.search, name='search'),
]