from django.db import models
from datetime import datetime

# Create your models here.
class slide(models.Model):
    caption = models.CharField(max_length=100)
    slide_img = models.FileField(upload_to='slide_img',default="")
    def __str__(self):
        return self.caption



class product(models.Model):
    CATEGORY = (
        ('Fruit', 'Fruit'),
        ('Veg', 'Veg'),
        ('offer', 'offer'),
    )
    CATEGORY1 = (
        ('offer', 'offer'),
        ('no catrgory', 'no catrgory'),
    )
    p_no = models.AutoField(primary_key=True)
    pname = models.CharField(max_length=100)
    category = models.CharField(max_length=200, null=True, choices=CATEGORY)
    category1 = models.CharField(max_length=200, null=True, choices=CATEGORY1)
    description= models.CharField(max_length=500)
    price1 = models.IntegerField()
    price_unit1 = models.CharField(max_length=100)
    price2 = models.IntegerField()
    price_unit2 = models.CharField(max_length=100)
    discount = models.CharField(max_length=50)
    product_img = models.FileField(upload_to='product_img',default="")
    def __str__(self):
        return self.pname

class user_cart(models.Model):
    orderid = models.IntegerField(null=True,blank=True)
    cuser = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    cart_count=models.IntegerField()
    price = models.IntegerField()
    price1 = models.CharField(max_length=100)
    img = models.CharField(max_length=500)
    qty = models.IntegerField()
    total = models.IntegerField()
    def __str__(self):
        return self.cuser

class coupon(models.Model):
    code = models.CharField(max_length=100)
    discount_percent=models.IntegerField()
    def __str__(self):
        return self.code  


class orders(models.Model):
    orderid = models.IntegerField()
    cuser = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    price1 = models.CharField(max_length=100)
    qty = models.IntegerField()
    total = models.IntegerField()
    def __str__(self):
        return self.cuser

class orders_owner(models.Model):
    orderid = models.IntegerField()
    cuser = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    pin = models.IntegerField()
    address = models.CharField(max_length=200)
    landmark = models.CharField(max_length=100)
    phone_number=models.IntegerField()
    MOP = models.CharField(max_length=100)
    net_amt = models.IntegerField()
    def __str__(self):
        return self.cuser

class orders_ID(models.Model):
    STATUS = (
        ('Pending', 'Pending'),
        ('Out for delivery', 'Out for delivery'),
        ('Delivered', 'Delivered')
    )
    MOP_STATUS=(
        ('COD', 'COD'),
        ('Online_Pay Failure', 'Online_Pay Failure'),
        ('Online_Pay Success', 'Online_Pay Success')
    )
    orderid = models.IntegerField()
    name = models.CharField(max_length=100)
    status = models.CharField(max_length=200, null=True, choices=STATUS)
    MOP = models.CharField(max_length=200, null=True, choices=MOP_STATUS)
    date = models.DateTimeField(default=datetime.now, blank=True)
    def __str__(self):
        return self.name

class profile(models.Model):
    cuser = models.CharField(max_length=100)
    profile_img = models.FileField(upload_to='profile_img',default="")
    nikname = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    pin = models.CharField(max_length=6)
    address = models.CharField(max_length=200)
    number = models.CharField(max_length=10)
    landmark = models.CharField(max_length=200)
    def __str__(self):
        return self.cuser
