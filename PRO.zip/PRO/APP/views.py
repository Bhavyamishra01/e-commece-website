import os
from django.conf import settings
from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.conf import settings
from django.templatetags.static import static
from django.contrib.auth.models import User
from APP.models import slide,product,user_cart,coupon,orders,orders_owner,orders_ID
from APP.models import profile as prof

from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.forms import UserCreationForm
from .forms import CreateUserForm

from django.contrib import messages
from datetime import datetime
import simplejson as json
from json import dumps 

from django.contrib.auth.decorators import login_required

MERCHANT_KEY = '4wG_uhmoD7&JSC02'
from PayTm import Checksum
from django.views.decorators.csrf import csrf_exempt
# Create your views here.

def index(request):
    print("HERE")
    user=str(request.user)
    request.session['user'] = user
    images=slide.objects.all()
    pdt=product.objects.filter(category='Fruit').order_by('-p_no')[:10]
    pdt1=product.objects.filter(category='Veg').order_by('-p_no')[:10]
    user=request.session['user']
    if user=='AnonymousUser':
        cart_count=request.session.get('cart_count','0')
        cart_data=request.session.get('cart_data','No Item In Cart')
        cart_data = dumps(cart_data)
        cart_count = dumps(cart_count)
        context1 = {'images' : images,'pdt':pdt,'pdt1':pdt1,'cart_data':cart_data,'cart_count':cart_count}
        return render(request, 'index.html',context1)
    else:
        cd=user_cart.objects.filter(cuser=request.session['user'])
        cart_count=0
        for a in cd:
            cart_count=cart_count+1
        cart_data='No Item In Cart'
        cart_data = dumps(cart_data)
        cart_count = dumps(cart_count)
        context1 = {'images' : images,'pdt':pdt,'pdt1':pdt1,'cart_data':cart_data,'cart_count':cart_count}
        return render(request, 'index.html',context1)
    print("HERE")
    context2 = {'images' : images,'pdt':pdt,'pdt1':pdt1}
    return render(request, "index.html", context2)

def quickview(request,mid):
    pdt=product.objects.filter(p_no=mid)
    if request.session['user']=='AnonymousUser':
        cart_count=request.session.get('cart_count','0')
        cart_data=request.session.get('cart_data','No Item In Cart')
        cart_data = dumps(cart_data)
        cart_count = dumps(cart_count)
        context1 = {'pdt':pdt,'cart_data':cart_data,'cart_count':cart_count}
        return render(request, 'quickview.html',context1)
    else:
        cd=user_cart.objects.filter(cuser=request.session['user'])
        cart_count=0
        for a in cd:
            cart_count=cart_count+1
        cart_data='No Item In Cart'
        cart_data = dumps(cart_data)
        cart_count = dumps(cart_count)
        context1 = {'pdt':pdt,'cart_data':cart_data,'cart_count':cart_count}
        return render(request, 'quickview.html',context1)
    return render(request,'quickview.html',{'pdt':pdt})

def register(request):
    user=str(request.user)
    request.session['user'] = user
    form = CreateUserForm()
    if request.method == "POST":
        form = CreateUserForm(request.POST)
        if form.is_valid():
            u=form.cleaned_data.get('username')
            e=form.cleaned_data.get('email')
            p=prof.objects.create(cuser=str(u),email=str(e),profile_img='slide_img/dpic.png')
            p.save()
            form.save()
            user = form.cleaned_data.get('username')
            #send email for register
            return redirect('login')
        else:
            context = {'form': form}
            return render(request, 'register.html', context)
    else:
        context = {'form': form}
        return render(request, 'register.html', context)

def login(request):
    user=str(request.user)
    request.session['user'] = user
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect('index')
        else: 
            messages.info(request, "Username or password is incorrect")

    context = {}
    return render(request, 'login.html', context)

def forget(request):
    try:
        email=request.POST["email"]
    except:
        return redirect("login")
    otp=request.POST["otp"]
    newpsd=request.POST["newpsd"]
    a=generateID()
    checkem=User.objects.filter(email=email)
    if 'OTP-BTN' in request.POST:
        if str(checkem)=="<QuerySet []>":
            messages.info(request,"Your Are Not Registered With As")
            return redirect("login")
        elif email=="":
            messages.info(request,"Something is missing")
            return redirect("login")
        else:
            print("OTP-BTN")
            #storing otp
            request.session['otp'] = a
            print(a)
            #send email with variable a
            #EMAIL PART
            messages.info(request, "OTP sent to Your Email")
            data={'email':email}
            return render(request,"login.html",data)
    elif 'Reset' in request.POST:
        if otp=="" or newpsd=="":
            messages.info(request,"Something is missing")
            return redirect("login")
        elif otp==request.session.get('otp'):
            user_data=User.objects.filter(email=email)
            username1=""
            for i in user_data:
                username1=str(i.username)
            
            u = User.objects.get(username=username1)
            u.set_password(newpsd)
            u.save()
            messages.info(request,"Your Password Is Changed")
            return redirect("login")
        else:
            messages.info(request,"OTP is wrong")
            return redirect("login")
    else:
        print("ERROR")
    return redirect("login")

def loginAdmin(request):
    if request.method =='GET':
        return render(request,"loginAdmin.html")
    else:
        pass
    request.session['userAdmin'] = 'adminak'
    username = request.POST['username']
    password = request.POST['password']
    if request.session.get('userAdmin') == username and password =='qazwsxedc@':
        return redirect('dashboard')
    else:
        pass
    return render(request,"loginAdmin.html")

@login_required(login_url='/login/')
def profile1(request):
    pro=prof.objects.all().filter(cuser=str(request.user))
    prop=prof.objects.get(cuser=str(request.user))
    oid=orders_ID.objects.filter(name=str(request.user)).order_by('-date')
    cd=user_cart.objects.filter(cuser=request.session['user'])
    cart_count=0
    for a in cd:
        cart_count=cart_count+1
    cart_count = dumps(cart_count)
    if request.method == "POST":
        if 'save_profile' in request.POST:
            nikname=request.POST['Nikname']
            email=request.POST['email']
            address=request.POST['address']
            landmark=request.POST['landmark']
            pin=request.POST['pin']
            number=request.POST['number']
            pro=prof.objects.filter(cuser=str(request.user))
            pro.update(nikname=nikname,email=email,address=address,landmark=landmark,pin=pin,number=number)
            return redirect('index')
        elif 'upload_btn' in request.POST:
            profile_imgg=request.FILES['upload_pic']
            prop.profile_img=profile_imgg
            prop.save()
        else:
            pass
        return render(request,"profile.html",locals())
    else:
        return render(request,"profile.html",locals())

@login_required
def logout(request):
    auth_logout(request)
    return redirect('login')

def search(request):
    if request.method=="POST":
        search=request.POST['search'].capitalize()
        pdt=product.objects.filter(pname=search)
        if str(pdt)=="<QuerySet []>":
            print("NF")
            msg5="product Not Found"
            data={'msg5':msg5}
            return render(request,"search.html",data)
        else:
            if request.session['user']=='AnonymousUser':
                cart_count=request.session.get('cart_count','0')
                cart_data=request.session.get('cart_data','No Item In Cart')
                cart_data = dumps(cart_data)
                cart_count = dumps(cart_count)
                context1 = {'pdt':pdt,'cart_data':cart_data,'cart_count':cart_count}
                return render(request, 'allfruit.html',context1)
            else:
                cd=user_cart.objects.filter(cuser=request.session['user'])
                cart_count=0
                for a in cd:
                    cart_count=cart_count+1
                cart_data='No Item In Cart'
                cart_data = dumps(cart_data)
                cart_count = dumps(cart_count)
                context1 = {'pdt':pdt,'cart_data':cart_data,'cart_count':cart_count}
                return render(request, 'allfruit.html',context1)
            context2 = {'pdt':pdt}
            return render(request, "allfruit.html", context2)
    else:
        return HttpResponse("Page Not Found")

def allfruit(request):
    pdt=product.objects.filter(category='Fruit')
    if request.session['user']=='AnonymousUser':
        cart_count=request.session.get('cart_count','0')
        cart_data=request.session.get('cart_data','No Item In Cart')
        cart_data = dumps(cart_data)
        cart_count = dumps(cart_count)
        context1 = {'pdt':pdt,'cart_data':cart_data,'cart_count':cart_count}
        return render(request, 'allfruit.html',context1)
    else:
        cd=user_cart.objects.filter(cuser=request.session['user'])
        cart_count=0
        for a in cd:
            cart_count=cart_count+1
        cart_data='No Item In Cart'
        cart_data = dumps(cart_data)
        cart_count = dumps(cart_count)
        context1 = {'pdt':pdt,'cart_data':cart_data,'cart_count':cart_count}
        return render(request, 'allfruit.html',context1)
    context2 = {'pdt':pdt}
    return render(request, "allfruit.html", context2)

def allveg(request):
    pdt1=product.objects.filter(category='Veg')
    if request.session['user']=='AnonymousUser':
        cart_count=request.session.get('cart_count','0')
        cart_data=request.session.get('cart_data','No Item In Cart')
        cart_data = dumps(cart_data)
        cart_count = dumps(cart_count)
        context1 = {'pdt1':pdt1,'cart_data':cart_data,'cart_count':cart_count}
        return render(request, 'allveg.html',context1)
    else:
        cd=user_cart.objects.filter(cuser=request.session['user'])
        cart_count=0
        for a in cd:
            cart_count=cart_count+1
        cart_data='No Item In Cart'
        cart_data = dumps(cart_data)
        cart_count = dumps(cart_count)
        context1 = {'pdt1':pdt1,'cart_data':cart_data,'cart_count':cart_count}
        return render(request, 'allveg.html',context1)
    context1 = {'pdt1':pdt1}
    return render(request, "allveg.html", context1)

def alloffers(request):
    alloff=product.objects.filter(category1='offer')
    if request.session['user']=='AnonymousUser':
        cart_count=request.session.get('cart_count','0')
        cart_data=request.session.get('cart_data','No Item In Cart')
        cart_data = dumps(cart_data)
        cart_count = dumps(cart_count)
        context1 = {'alloff':alloff,'cart_data':cart_data,'cart_count':cart_count}
        return render(request, 'alloffers.html',context1)
    else:
        cd=user_cart.objects.filter(cuser=request.session['user'])
        cart_count=0
        for a in cd:
            cart_count=cart_count+1
        cart_data='No Item In Cart'
        cart_data = dumps(cart_data)
        cart_count = dumps(cart_count)
        context1 = {'alloff':alloff,'cart_data':cart_data,'cart_count':cart_count}
        return render(request, 'alloffers.html',context1)
    context1 = {'alloff':alloff}
    return render(request, "alloffers.html", context1)

def about(request):
    return render(request,"about.html")

@csrf_exempt
def addtocart(request):
    print(request.method)
    if request.method == 'POST':
        if request.session['user']=='AnonymousUser':
            new_cart_no = int(request.POST.get('cart_count'))+1
            request.session['cart_count'] = new_cart_no
            request.session['cart_data'] = request.POST.get('cart_data')
            return HttpResponse(new_cart_no)
        else:
            new_cart_no = int(request.POST.get('cart_count'))+1
            cart_data= request.POST.get('cart_data')
            print(cart_data)
            user=request.POST.get('user')
            cart_data_list=list(cart_data.split(","))
            cart_data_list.pop(0)
            t=0
            for i in range(0,1):
                for j in range(t,1+t):
                    cd=user_cart()
                    cd.cuser=request.session['user']
                    cd.img=cart_data_list[j]
                    cd.name=cart_data_list[j+1]
                    cd.qty=cart_data_list[j+2]
                    cd.price=cart_data_list[j+4]
                    cd.price1=cart_data_list[j+3]
                    cd.total=cart_data_list[j+4]
                    cd.cart_count=new_cart_no
                    cd.save()
                    t=t+5
                    j=0
                    print("OK")
            
            cd=user_cart.objects.filter(cuser=request.session['user'])
            new_cart_no=0
            for a in cd:
                new_cart_no=new_cart_no+1
            return HttpResponse(new_cart_no)
    else:
        return HttpResponse("Request method is GET")

def cart_data(request):
    try:
        request.session['user']
    except:
        return HttpResponse("Page Not Found")
    if request.session['user']=='AnonymousUser':
        cart_count=request.session.get('cart_count','0')
        cart_data=request.session.get('cart_data','No Item In Cart')
        cart_data = dumps(cart_data)
        print(cart_data)
        cart_count = dumps(cart_count)
        return render(request, 'cart.html',{'cart_data':cart_data,'cart_count':cart_count})
    else:
        cd=user_cart.objects.filter(cuser=request.session['user'])
        s="No Item In Cart"+","
        cart_count=0
        mytotal=0
        for a in cd:
            cart_count=cart_count+1
            s=s+a.img+","
            s=s+a.name+","
            s=s+str(a.qty)+","
            s=s+str(a.price1)+","
            s=s+str(a.total)+","
            mytotal=mytotal+int(a.total)
        
        request.session['mytotal']=mytotal
        cart_count = dumps(cart_count)
        cart_data=s
        cart_data = dumps(cart_data)
        print(cart_data)
        return render(request, 'cart.html',{'cart_data':cart_data,'cart_count':cart_count})

@csrf_exempt   
def updatecart(request):
    if request.method == 'POST':
        if request.session['user']=='AnonymousUser':
            new_cart_no = int(request.POST.get('cart_count'))
            request.session['cart_count'] = new_cart_no
            request.session['cart_data'] = request.POST.get('cart_data')
            cart_data=request.session.get('cart_data','No Item In Cart')
            return HttpResponse(new_cart_no)
        else:
            cd=user_cart.objects.filter(cuser=request.session['user'])
            cd.delete()
            new_cart_no = int(request.POST.get('cart_count'))
            cart_data= request.POST.get('cart_data')
            user=request.POST.get('user')
            cart_data_list=list(cart_data.split(","))
            cart_data_list.pop(0)
            t=0
            mytotal=0
            for i in range(0,new_cart_no):
                for j in range(t,1+t):
                    cd=user_cart()
                    cd.cuser=request.session['user']
                    cd.img=cart_data_list[j]
                    cd.name=cart_data_list[j+1]
                    cd.qty=cart_data_list[j+2]
                    cd.price=cart_data_list[j+4]
                    cd.price1=cart_data_list[j+3]
                    cd.total=cart_data_list[j+4]
                    cd.cart_count=new_cart_no
                    mytotal=int(cart_data_list[j+4])
                    cd.save()
                    t=t+5
            cd=user_cart.objects.filter(cuser=request.session['user'])
            new_cart_no=0
            for a in cd:
                new_cart_no=new_cart_no+1
            return HttpResponse(new_cart_no)
    else:
        return HttpResponse("Request method is not a GET")

@login_required(login_url='/login/')
def checkout(request):
    pro=prof.objects.all().filter(cuser=str(request.user))
    net_amt=int(request.session['mytotal'])
    cd=user_cart.objects.filter(cuser=request.session['user'])
    new_cart_no=0
    for a in cd:
        new_cart_no=new_cart_no+1
    print(new_cart_no)
    request.session['net_amt'] = str(net_amt)
    cart_count = dumps(new_cart_no)
    data={'cd':cd,'net_amt':net_amt,'cart_count':cart_count,'pro':pro}
    return render(request,"checkout.html",data)

import math, random 
def generateID() :  
    digits = "0123456789"
    orderid = ""
    for i in range(4) : 
        orderid += digits[math.floor(random.random() * 10)] 
    return orderid 

@login_required(login_url='/login/')
def placeorder(request):
    orderid=int(generateID())
    request.session['orderid']=str(orderid)
    print(request.session.get('orderid'))
    
    net_amt=int(request.session.get('net_amt'))
    try:
        MOP=request.POST['Mode']
    except:
        messages.info(request, "Click on cash on delivery")
        return redirect("checkout")

    user=str(request.user)
    net_amt=int(request.session.get('net_amt'))
    name=request.POST['name']
    email=request.POST['email']
    pin=request.POST['pin']
    address=request.POST['address']
    number=request.POST['number']
    landmark=request.POST['landmark']
    if name=="" or email=="" or pin=="" or address=="" or number=="" or landmark=="" or MOP=="":
        messages.info(request, "Please Fill All Field")
        return redirect('checkout')
    elif MOP=="Pay_online":
        #code here to pay Online
        owner=orders_owner(cuser=user,name=name,email=email,pin=pin,address=address,landmark=landmark,phone_number=number, MOP=MOP,net_amt=net_amt,orderid=orderid)
        owner.save()
        cd=user_cart.objects.filter(cuser=request.session['user'])
        temp=0
        for i in cd:
            ods=orders(orderid=orderid,cuser=i.cuser,
            name=i.name,
            price1=i.price1,
            qty=i.qty,
            total=i.total,
            )
            ods.save()
            temp=temp+1

        oid=orders_ID(orderid=orderid,name=user,status='Pending',MOP='Online_Pay Failure')
        oid.save()
        cd=user_cart.objects.filter(cuser=request.session['user']).update(orderid=orderid)
        #cd.delete()
        param_dict = {

                'MID': 'dAicIK59813679161990',
                'ORDER_ID': str(orderid),
                'TXN_AMOUNT': str(net_amt),
                'CUST_ID': 'ak',
                'INDUSTRY_TYPE_ID': 'Retail',
                'WEBSITE': 'WEBSTAGING',
                'CHANNEL_ID': 'WEB',
                'CALLBACK_URL':'http://127.0.0.1:8000/handlerequest/',

        }
        param_dict['CHECKSUMHASH'] = Checksum.generate_checksum(param_dict, MERCHANT_KEY)
        return render(request, 'paytm.html', {'param_dict': param_dict})
    elif MOP=="COD":
        owner=orders_owner(cuser=user,name=name,email=email,pin=pin,address=address,landmark=landmark,phone_number=number, MOP=MOP,net_amt=net_amt,orderid=orderid)
        owner.save()
        cd=user_cart.objects.filter(cuser=request.session['user'])
        temp=0
        for i in cd:
            ods=orders(orderid=orderid,cuser=i.cuser,
            name=i.name,
            price1=i.price1,
            qty=i.qty,
            total=i.total,
            )
            ods.save()
            temp=temp+1

        oid=orders_ID(orderid=orderid,name=user,status='Pending',MOP='COD')
        oid.save()
        cd.delete()
        #SEND EMAIL FOR Placing Orders
        response_dict={"RESPCODE":"01","ORDERID":str(orderid),"MESSAGE":"YOUR ORDERS ARE PLACED","MOP":"Cash On Delivery"}
        return render(request, 'paymentstatus.html', {'response': response_dict})
    else:
        return HttpResponse("SOMETHIG WENT WRONG")

@csrf_exempt
def handlerequest(request):
    # paytm will send you post request here
    form = request.POST
    response_dict = {}
    for i in form.keys():
        response_dict[i] = form[i]
        if i == 'CHECKSUMHASH':
            checksum = form[i]

    verify = Checksum.verify_checksum(response_dict, MERCHANT_KEY, checksum)
    if verify:
        orderid=response_dict['ORDERID']
        if response_dict['RESPCODE'] == '01':
            oid=orders_ID.objects.filter(orderid=orderid).update(MOP='Online_Pay Success')
            #empty the cart
            uc=user_cart.objects.filter(orderid=orderid)
            uc.delete()
            print('order successful')
        else:
            print(response_dict)
            orderid=response_dict['ORDERID']
            o=orders.objects.filter(orderid=orderid)
            o.delete()
            oid=orders_ID.objects.filter(orderid=orderid)
            oid.delete()
            oo=orders_owner.objects.filter(orderid=orderid)
            oo.delete()
            print('order was not successful because' + response_dict['RESPMSG'])
    return render(request, 'paymentstatus.html', {'response': response_dict})

@login_required(login_url='/login/')
def profile(request):
    return render(request,"profile.html")

def dashboard(request):
    if request.session.get('userAdmin')=="adminak":
        oid_p=orders_ID.objects.filter(status='Pending')
        oid_od=orders_ID.objects.filter(status='Out for delivery')
        oid_d=orders_ID.objects.filter(status='Delivered')
        p=0
        od=0
        d=0
        for i in oid_p:
            p=p+1
        for i in oid_od:
            od=od+1
        for i in oid_d:
            d=d+1
        
        data1={'p':p,'od':od,'d':d}
        if 'totalorder' in request.POST:
            oid=orders_ID.objects.all().order_by('-date__time')
            data={'oid':oid}
            return render(request,"dashboard.html",locals())
        elif 'Pending' in request.POST:
            oid=orders_ID.objects.filter(status='Pending').order_by('-date__time')
            data={'oid':oid}
            return render(request,"dashboard.html",locals())
        elif 'OUTD' in request.POST:
            oid=orders_ID.objects.filter(status='Out for delivery').order_by('-date__time')
            data={'oid':oid}
            return render(request,"dashboard.html",locals())
        elif 'Delivery' in request.POST:
            oid=orders_ID.objects.filter(status='Delivered').order_by('-date__time')
            data={'oid':oid}
            return render(request,"dashboard.html",locals())
        elif 'all_cod' in request.POST:
            oid=orders_ID.objects.filter(MOP='COD').order_by('-date__time')
            data={'oid':oid}
            return render(request,"dashboard.html",locals())
        elif 'all_OP' in request.POST:
            oid=orders_ID.objects.exclude(MOP='COD').order_by('-date__time')
            data={'oid':oid}
            return render(request,"dashboard.html",locals())
        elif 'Delete' in request.POST:
            pname=request.POST['product_name']
            p=product.objects.filter(pname=pname)
            if str(p)=="<QuerySet []>":
                msg="This product not found in database"
                data={'msg':msg}
                return render(request,"dashboard.html",locals())
            else:
                p.delete()
                msg="Your product:"+str(pname)+" is get deleted"
                data={'msg':msg}
                return render(request,"dashboard.html",locals())
        elif 'CS' in request.POST:
            ord_id=request.POST['ord_id']
            status=request.POST['status']
            p=orders_ID.objects.filter(orderid=ord_id)
            if status=="":
                msg="This is Your Current Status"
                data={'msg':msg}
                return render(request,"dashboard.html",locals())
            elif str(p)=="<QuerySet []>":
                msg="This order is not found in database"
                data={'msg':msg}
                return render(request,"dashboard.html",locals())
            else:
                orders_ID.objects.filter(orderid=ord_id).update(status=status)
                msg="Status Got Updated of ID:"+str(ord_id)
                data={'msg':msg}
                return render(request,"dashboard.html",locals())
        elif 'add_pro' in request.POST:
            Name=request.POST['Name'].capitalize()
            print(Name)
            Category_1=request.POST['Category_1']
            Category_2=request.POST['Category_2']
            Description=request.POST['Description']
            Price1=request.POST['Price1']
            Price1_tag=request.POST['Price1_tag']
            Price2=request.POST['Price2']
            Price2_tag=request.POST['Price2_tag']
            Discount_tag=request.POST['Discount']
            try:
                P_img=request.FILES['P_img']
            except:
                msg="Image is Missing"
                print(request.FILES)
                data={'msg':msg}
                return render(request,"dashboard.html",locals())
            if Name=="" or Category_1=="" or Category_2=="" or Description=="" or Price1=="" or Price1_tag=="" or Price2=="" or Price2_tag=="" or Discount_tag=="" or P_img == "":
                msg="Something is Missing"
                print(request.FILES)
                data={'msg':msg}
                return render(request,"dashboard.html",locals())
            else:
                p=product(pname=Name,category=Category_1,category1=Category_2,description=Description,price1=Price1,price_unit1=Price1_tag,price2=Price2,price_unit2=Price2_tag,discount=Discount_tag,product_img=P_img)
                p.save()
                msg="Product is Added"
                data={'msg':msg}
                return render(request,"dashboard.html",locals())
        elif 'delete_this' in request.POST:
            orderid=request.POST['MOP']
            o=orders.objects.filter(orderid=orderid)
            o.delete()
            oid=orders_ID.objects.filter(orderid=orderid)
            oid.delete()
            oo=orders_owner.objects.filter(orderid=orderid)
            oo.delete()
            msg="The orders of ID "+str(orderid)+" are removed"
            data={'msg':msg}
            return render(request,"dashboard.html",locals())
        else:
            return render(request,"dashboard.html",data1)
    else:
        return HttpResponse('<h1>Page not found</h1>')
    
def dash(request,ids):
    print(request.user)
    if request.session.get('userAdmin')=="adminak":
        ord_id=ids
        order=orders.objects.filter(orderid=ord_id)
        customer=orders_owner.objects.filter(orderid=ord_id)
        data={'order':order,'customer':customer}
    else:
        return HttpResponse('<h1>Page not found</h1>')
    return render(request,"orders.html",data)

@login_required(login_url='/login/')
def customer_orders(request,ids):
    ord_id=ids
    order=orders.objects.filter(orderid=ord_id)
    customer=orders_owner.objects.filter(orderid=ord_id)
    data={'order':order,'customer':customer}
    return render(request,"orders.html",data)