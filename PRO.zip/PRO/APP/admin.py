from django.contrib import admin

# Register your models here.
from APP.models import *
admin.site.register(slide)
admin.site.register(product)
admin.site.register(user_cart)

admin.site.register(coupon)
admin.site.register(orders)
admin.site.register(orders_owner)
admin.site.register(orders_ID)
admin.site.register(profile)

admin.site.site_header = "SHOP Admin"
admin.site.site_title = "SHOP Admin Portal"
admin.site.index_title = "Welcome to ONLINE SHOP Portal"